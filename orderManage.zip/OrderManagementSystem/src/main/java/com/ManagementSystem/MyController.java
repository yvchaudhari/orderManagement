package com.ManagementSystem;

import java.util.List;
import java.util.Optional; // Use the correct Optional class

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;



@RestController
@CrossOrigin
public class MyController {
    
    @Autowired
    private OrderRepository orderrepo;
    
    @PostMapping("/save")
    public Ordermanage saveOrder(@RequestBody Ordermanage order) {
        return orderrepo.save(order);
    }
    
    @GetMapping("/getAll")
    public List<Ordermanage> getAll() {
        return orderrepo.findAll();
    }
    
  
   
    @PutMapping("get/{id}")
    public ResponseEntity<?> updateTotalAmount(
            @PathVariable Long id, 
            @RequestParam(required = false, defaultValue = "0.0") Double newTotalAmount) {
        try {
            if (newTotalAmount == null || newTotalAmount <= 0) {
                return ResponseEntity.badRequest().body("Invalid or missing 'newTotalAmount' parameter.");
            }

            Optional<Ordermanage> orderOptional = orderrepo.findById(id);

            if (orderOptional.isPresent()) {
                Ordermanage order = orderOptional.get();
                order.setTotalAmount(newTotalAmount);
                orderrepo.save(order);
                return ResponseEntity.ok(order);
            } else {
                return ResponseEntity.status(404).body("Order not found with id: " + id);
            }
        } catch (Exception e) {
            return ResponseEntity.status(500).body("Error updating order: " + e.getMessage());
        }
    }

}
