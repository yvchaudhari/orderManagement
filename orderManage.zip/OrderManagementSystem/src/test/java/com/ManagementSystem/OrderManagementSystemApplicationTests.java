package com.ManagementSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrderManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
